/* s3N10r sZcR1pTzC!!!!!1!1!!*/
$(document).ready( function() {
	var htmlWordMatch = /(<\/?\w+(?:(?:\s+\w+(?:\s*=\s*(?:".*?"|'.*?'|[^'">\s]+))?)+\s*|\s*)\/?>)/gim;
	$('.blink').modernBlink();
	$('.lastUpdated').append('Last updated: ' + document.lastModified);
	$('.urlLastUpdated').each( function() {
		var element = $(this);
		getlastmod(element.attr("rel"), appendLastModeDate, element);
	});
	
	function appendLastModeDate(element, date) {
		element.append('Last updated: ' + date);
	}
	
	function getlastmod(url, cb, element) {
	    var req = new XMLHttpRequest();
	    req.open("GET", url);
	    req.addEventListener("load", function() {
	        cb(element, req.getResponseHeader("Last-Modified"));
	    }, false);
	    req.send(null);
	}
	$('.counter').each( function() {
		var element = $(this);
		var digits = element.attr("rel");
		var counter = "";
		for (var i=0; i<=digits; i++) 
			counter += Math.floor(Math.random()*8) + 1 + "";
		element.append(counter);
	});
	$('.link').click(function(){ window.location = $(this).attr('rel'); });
	$('.l33TsP33k').each( function() {
		var output = "";
		var tokens = $(this).html().split(htmlWordMatch);
		var tokenLength = tokens.length;
		for(var i=0; i<tokenLength; i++) {
			var token = tokens[i].trim();
			if (token != "") {
				if (token.substring(0,1) !="<") {
					var words = token.split(/\s+/);
					var length = words.length;
					for (var j=0; j < length; j++) {
						var word = words[j].trim();
						if (word != "")
							output += "<span class=\"l33Tf1RsT\">" + word.substring(0,1) + "</span>" + word.substring(1,word.length) + " ";
					}
				}
				else {
					output += token;
				}
			}
		};
		$(this).html(output);
	});
	$('#homeMenu .menuItem .icon').each( function() {
		var link = $(this).parent().find('.text a')[0];
		if (link != "" ) {
			if (link.target != null) 
				$(this).click(function() { window.open(link.href, link.target); });
			else
				$(this).click(function() { window.location = link.attr('href'); });
		}
		else 
			$(this).css('cursor', 'default');
	});
});
